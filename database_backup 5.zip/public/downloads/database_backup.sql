--
-- PostgreSQL database dump
--

\restrict wei7zNf8XlgkmhVBWS5GzlRNrFQt764XZaYmTbvdZ8F4EcbLTfYvhmN58Ltr8OI

-- Dumped from database version 15.19 (Debian 15.19-0+deb12u1)
-- Dumped by pg_dump version 15.19 (Debian 15.19-0+deb12u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.statuses DROP CONSTRAINT IF EXISTS statuses_user_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.statuses DROP CONSTRAINT IF EXISTS statuses_attachment_id_attachments_id_fk;
ALTER TABLE IF EXISTS ONLY public.status_views DROP CONSTRAINT IF EXISTS status_views_viewer_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.status_views DROP CONSTRAINT IF EXISTS status_views_status_id_statuses_id_fk;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_user_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.reports DROP CONSTRAINT IF EXISTS reports_reporter_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.reports DROP CONSTRAINT IF EXISTS reports_reported_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_sender_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_conversation_id_conversations_id_fk;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_attachment_id_attachments_id_fk;
ALTER TABLE IF EXISTS ONLY public.friendships DROP CONSTRAINT IF EXISTS friendships_requester_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.friendships DROP CONSTRAINT IF EXISTS friendships_addressee_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS conversations_created_by_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.conversation_members DROP CONSTRAINT IF EXISTS conversation_members_user_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.conversation_members DROP CONSTRAINT IF EXISTS conversation_members_conversation_id_conversations_id_fk;
ALTER TABLE IF EXISTS ONLY public.calls DROP CONSTRAINT IF EXISTS calls_receiver_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.calls DROP CONSTRAINT IF EXISTS calls_conversation_id_conversations_id_fk;
ALTER TABLE IF EXISTS ONLY public.calls DROP CONSTRAINT IF EXISTS calls_caller_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.blocks DROP CONSTRAINT IF EXISTS blocks_blocker_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.blocks DROP CONSTRAINT IF EXISTS blocks_blocked_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.attachments DROP CONSTRAINT IF EXISTS attachments_owner_id_users_id_fk;
ALTER TABLE IF EXISTS ONLY public.attachments DROP CONSTRAINT IF EXISTS attachments_conversation_id_conversations_id_fk;
DROP INDEX IF EXISTS public.statuses_user_idx;
DROP INDEX IF EXISTS public.statuses_expires_idx;
DROP INDEX IF EXISTS public.sessions_user_idx;
DROP INDEX IF EXISTS public.sessions_expires_idx;
DROP INDEX IF EXISTS public.messages_sender_client_uq;
DROP INDEX IF EXISTS public.messages_recipient_status_idx;
DROP INDEX IF EXISTS public.messages_conversation_seq_uq;
DROP INDEX IF EXISTS public.messages_conversation_change_idx;
DROP INDEX IF EXISTS public.messages_attachment_idx;
DROP INDEX IF EXISTS public.members_user_idx;
DROP INDEX IF EXISTS public.friendships_requester_idx;
DROP INDEX IF EXISTS public.friendships_addressee_idx;
DROP INDEX IF EXISTS public.calls_started_idx;
DROP INDEX IF EXISTS public.calls_receiver_idx;
DROP INDEX IF EXISTS public.calls_caller_idx;
DROP INDEX IF EXISTS public.attachments_conversation_idx;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_unique;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_public_id_unique;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_unique;
ALTER TABLE IF EXISTS ONLY public.statuses DROP CONSTRAINT IF EXISTS statuses_pkey;
ALTER TABLE IF EXISTS ONLY public.status_views DROP CONSTRAINT IF EXISTS status_views_status_id_viewer_id_pk;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_token_hash_unique;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.reports DROP CONSTRAINT IF EXISTS reports_pkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_pkey;
ALTER TABLE IF EXISTS ONLY public.friendships DROP CONSTRAINT IF EXISTS friendships_pkey;
ALTER TABLE IF EXISTS ONLY public.friendships DROP CONSTRAINT IF EXISTS friendships_pair_key_unique;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS conversations_pkey;
ALTER TABLE IF EXISTS ONLY public.conversations DROP CONSTRAINT IF EXISTS conversations_direct_key_unique;
ALTER TABLE IF EXISTS ONLY public.conversation_members DROP CONSTRAINT IF EXISTS conversation_members_conversation_id_user_id_pk;
ALTER TABLE IF EXISTS ONLY public.calls DROP CONSTRAINT IF EXISTS calls_pkey;
ALTER TABLE IF EXISTS ONLY public.blocks DROP CONSTRAINT IF EXISTS blocks_blocker_id_blocked_id_pk;
ALTER TABLE IF EXISTS ONLY public.attachments DROP CONSTRAINT IF EXISTS attachments_pkey;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.statuses;
DROP TABLE IF EXISTS public.status_views;
DROP TABLE IF EXISTS public.sessions;
DROP TABLE IF EXISTS public.reports;
DROP TABLE IF EXISTS public.messages;
DROP TABLE IF EXISTS public.friendships;
DROP TABLE IF EXISTS public.conversations;
DROP TABLE IF EXISTS public.conversation_members;
DROP TABLE IF EXISTS public.calls;
DROP TABLE IF EXISTS public.blocks;
DROP TABLE IF EXISTS public.attachments;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: attachments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attachments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    owner_id uuid NOT NULL,
    conversation_id uuid,
    kind text NOT NULL,
    mime_type text NOT NULL,
    size_bytes bigint NOT NULL,
    original_name text DEFAULT ''::text NOT NULL,
    storage_key text NOT NULL,
    duration_ms integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.attachments OWNER TO postgres;

--
-- Name: blocks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blocks (
    blocker_id uuid NOT NULL,
    blocked_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.blocks OWNER TO postgres;

--
-- Name: calls; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.calls (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    caller_id uuid NOT NULL,
    receiver_id uuid NOT NULL,
    conversation_id uuid,
    type text DEFAULT 'audio'::text NOT NULL,
    status text DEFAULT 'missed'::text NOT NULL,
    duration_sec integer DEFAULT 0 NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    answered_at timestamp with time zone,
    ended_at timestamp with time zone,
    viewed_by_receiver boolean DEFAULT false NOT NULL
);


ALTER TABLE public.calls OWNER TO postgres;

--
-- Name: conversation_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conversation_members (
    conversation_id uuid NOT NULL,
    user_id uuid NOT NULL,
    joined_at timestamp with time zone DEFAULT now() NOT NULL,
    role text DEFAULT 'member'::text NOT NULL,
    pinned boolean DEFAULT false NOT NULL,
    archived boolean DEFAULT false NOT NULL,
    muted boolean DEFAULT false NOT NULL,
    cleared_before_seq bigint DEFAULT 0 NOT NULL,
    last_read_seq bigint DEFAULT 0 NOT NULL,
    custom_wallpaper text DEFAULT ''::text NOT NULL,
    deleted_for_me boolean DEFAULT false NOT NULL
);


ALTER TABLE public.conversation_members OWNER TO postgres;

--
-- Name: conversations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conversations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    type text DEFAULT 'direct'::text NOT NULL,
    direct_key text,
    created_by uuid,
    last_seq bigint DEFAULT 0 NOT NULL,
    last_message_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    title text,
    description text DEFAULT ''::text,
    avatar_id uuid,
    is_group boolean DEFAULT false NOT NULL
);


ALTER TABLE public.conversations OWNER TO postgres;

--
-- Name: friendships; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.friendships (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pair_key text NOT NULL,
    requester_id uuid NOT NULL,
    addressee_id uuid NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    responded_at timestamp with time zone
);


ALTER TABLE public.friendships OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    conversation_id uuid NOT NULL,
    sender_id uuid NOT NULL,
    recipient_id uuid,
    client_id text NOT NULL,
    seq bigint NOT NULL,
    change_seq bigint NOT NULL,
    type text DEFAULT 'text'::text NOT NULL,
    body text,
    attachment_id uuid,
    status text DEFAULT 'sent'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    delivered_at timestamp with time zone,
    read_at timestamp with time zone,
    edited_at timestamp with time zone,
    deleted_at timestamp with time zone,
    reply_to_id uuid,
    forwarded boolean DEFAULT false NOT NULL
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    reporter_id uuid NOT NULL,
    reported_id uuid NOT NULL,
    message_id uuid,
    reason text NOT NULL,
    details text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.reports OWNER TO postgres;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token_hash text NOT NULL,
    user_agent text DEFAULT ''::text NOT NULL,
    ip text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: status_views; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.status_views (
    status_id uuid NOT NULL,
    viewer_id uuid NOT NULL,
    viewed_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.status_views OWNER TO postgres;

--
-- Name: statuses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.statuses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    type text DEFAULT 'text'::text NOT NULL,
    body text,
    attachment_id uuid,
    bg_color text DEFAULT '#059669'::text NOT NULL,
    font text DEFAULT 'default'::text NOT NULL,
    privacy text DEFAULT 'friends'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


ALTER TABLE public.statuses OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    public_id text NOT NULL,
    email text NOT NULL,
    username text NOT NULL,
    display_name text NOT NULL,
    bio text DEFAULT 'مرحبًا! أنا أستخدم Friend ID.'::text NOT NULL,
    password_hash text NOT NULL,
    avatar_id uuid,
    findable_by_name boolean DEFAULT true NOT NULL,
    messages_from text DEFAULT 'everyone'::text NOT NULL,
    show_last_seen boolean DEFAULT true NOT NULL,
    last_seen_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    theme_mode text DEFAULT 'light'::text NOT NULL,
    accent_color text DEFAULT '#059669'::text NOT NULL,
    wallpaper text DEFAULT ''::text NOT NULL,
    notify_messages boolean DEFAULT true NOT NULL,
    notify_groups boolean DEFAULT true NOT NULL,
    notify_calls boolean DEFAULT true NOT NULL,
    notify_sounds boolean DEFAULT true NOT NULL,
    privacy_photo text DEFAULT 'everyone'::text NOT NULL,
    privacy_status text DEFAULT 'friends'::text NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.attachments VALUES ('48329a84-87a7-483b-8630-54eb6d1b0795', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '7a625b76-551d-4a6a-a540-a468874fd95d', 'video', 'video/mp4', 8627867, '93b6be2b129e44568bb3a267e5a9c651.mp4', '2026/10/2f581947-e641-4f4b-9678-8af3f3b30efe', 16067, '2026-10-27 19:35:46.71177+00');
INSERT INTO public.attachments VALUES ('3d520ade-d12c-408a-ae53-1ba6008f5e66', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', NULL, 'status', 'video/mp4', 377855, 'abod_video.mp4', '2026/10/326e0a60-cb3f-4e4b-955b-331f3b68f9cf', NULL, '2026-10-27 19:36:45.304741+00');
INSERT INTO public.attachments VALUES ('db75b0f8-10fc-4956-be3b-81480eb094a8', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', NULL, 'status', 'video/mp4', 2304934, '30522b5707484bddadb0033376460aed.mp4', '2026/10/d60156b2-ea36-4869-8c2b-2e83de3b8e70', NULL, '2026-10-27 19:43:31.743572+00');
INSERT INTO public.attachments VALUES ('1cca4230-9e2e-46aa-a0e3-c05d4a4fa52a', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'audio', 'audio/webm', 312009, 'voice-1793212582912.webm', '2026/10/b7ceae15-601e-4beb-9b87-f18a365746b3', 11715, '2026-10-28 18:36:39.781463+00');
INSERT INTO public.attachments VALUES ('8cb8302c-2440-4fd6-9962-f080d8baa8c8', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'audio', 'audio/webm', 193660, 'voice-1793212613479.webm', '2026/10/562494c1-d42b-4e16-902e-c461a8c454b7', 7225, '2026-10-28 18:37:02.318069+00');
INSERT INTO public.attachments VALUES ('b28ef1fe-861b-4aeb-afb1-3616bd8d77db', '42f88079-1575-43a3-89fa-fd15eefdeb78', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'audio', 'audio/webm', 21321, 'voice-1793212622924.webm', '2026/10/8a4a42c1-cfdc-4f68-bbe8-30165cf2cb8f', 2151, '2026-10-28 18:37:06.001922+00');
INSERT INTO public.attachments VALUES ('d96496e1-6c49-40cd-8e09-1d70781cc4bc', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'image', 'image/jpeg', 1417539, '3E870DF0-7AF6-4C6A-8E74-DA646D9914FE.jpeg', '2026/10/487e45ba-d26c-43cf-88ea-540c6094567c', NULL, '2026-10-28 18:37:19.210535+00');
INSERT INTO public.attachments VALUES ('8cf56679-2fdb-40c7-a12c-d7df290c485f', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'audio', 'audio/webm', 448570, 'voice-1793212650090.webm', '2026/10/934ea9a9-5644-4c3e-9004-644a4ebcf04e', 17132, '2026-10-28 18:37:49.80647+00');
INSERT INTO public.attachments VALUES ('603eaedd-5cc6-48b6-b40c-f7f5f7dc1c99', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'audio', 'audio/webm', 198244, 'voice-1793212676526.webm', '2026/10/d6e045db-b050-4432-b6be-9f64a6beae7e', 7449, '2026-10-28 18:38:06.183375+00');
INSERT INTO public.attachments VALUES ('1c573f4f-ba36-4f7b-b598-19bb45e7e582', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'audio', 'audio/webm', 283905, 'voice-1793212710151.webm', '2026/10/03d40075-5706-4077-96a0-b8f574d6f1d8', 10567, '2026-10-28 18:39:06.806597+00');
INSERT INTO public.attachments VALUES ('0d87ffde-a292-4f3a-a3d1-05c96d86e7a4', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'audio', 'audio/webm', 273442, 'voice-1793212764952.webm', '2026/10/4c244597-8b01-4c74-9356-59e95e1b380c', 10199, '2026-10-28 18:39:39.22844+00');
INSERT INTO public.attachments VALUES ('c01cdc6a-9b55-4003-bd43-9814adbd90a0', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'audio', 'audio/webm', 112193, 'voice-1793212878313.webm', '2026/10/e28a84ee-75d1-4f19-88bd-e91ee1fd9db8', 4224, '2026-10-28 18:42:35.888159+00');
INSERT INTO public.attachments VALUES ('f011d6fa-f18c-4c31-8771-4762c657ad94', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'audio', 'audio/webm', 131354, 'voice-1793212973137.webm', '2026/10/c3b1aafd-6b8d-4a45-88c2-5beea7bb82f6', 5097, '2026-10-28 18:43:04.285262+00');
INSERT INTO public.attachments VALUES ('042f6845-e150-492a-b933-d91b56f68265', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'audio', 'audio/webm', 2036, 'voice-1793219769314.webm', '2026/10/584f1837-b276-4e04-a984-a165f6fa2b63', 72, '2026-10-28 20:36:10.391317+00');
INSERT INTO public.attachments VALUES ('031a6c25-ece3-4ce7-96ef-621610522c3c', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'audio', 'audio/webm', 138162, 'voice-1793219771935.webm', '2026/10/fbe4055d-5a0d-4660-ba77-91ea89c844a4', 5365, '2026-10-28 20:36:18.973214+00');
INSERT INTO public.attachments VALUES ('65ba11d6-8686-4b94-a212-6629431af417', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'image', 'image/png', 338154, 'IMG_2459.png', '2026/10/d8010559-765e-4759-9a9f-6e59327ac776', NULL, '2026-10-28 20:36:46.460189+00');
INSERT INTO public.attachments VALUES ('cc0bd85d-5260-43ca-9d97-c9f5e26896e7', '65960192-c89e-471f-9ef9-8063e26ec2de', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'audio', 'audio/webm', 84665, 'voice-1793219814596.webm', '2026/10/aa736135-2500-4c86-8f8b-ce90c0b5e561', 3127, '2026-10-28 20:36:59.909922+00');
INSERT INTO public.attachments VALUES ('ee64f00a-326d-4b1f-bcc4-3ca87c564121', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'video', 'video/mp4', 17833249, 'ScreenRecording_10-28-2026 23-37-14_1.mp4', '2026/10/9f45c636-bdf6-4792-9bae-6b17e5383360', 13670, '2026-10-28 20:38:53.101019+00');
INSERT INTO public.attachments VALUES ('c11c4353-68d4-452f-b9da-ef157e2685ef', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'audio', 'audio/webm', 229922, 'voice-1793219861733.webm', '2026/10/abf25797-2da8-4296-86e6-b60d17c9cc0a', 8570, '2026-10-28 20:38:54.553628+00');


--
-- Data for Name: blocks; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: calls; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.calls VALUES ('8f1aea50-d2cf-4110-bb64-21dd39e1ce11', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', NULL, 'audio', 'declined', 0, '2026-10-28 18:35:10.704389+00', NULL, '2026-10-28 18:35:30.615+00', true);
INSERT INTO public.calls VALUES ('512cc783-f1d9-4b4b-8bb3-b8ae97e09e82', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', NULL, 'video', 'declined', 0, '2026-10-28 18:35:34.070516+00', NULL, '2026-10-28 18:35:48.244+00', true);
INSERT INTO public.calls VALUES ('bc3b0b64-05a5-4bdc-abc6-63b76ee5b275', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', NULL, 'audio', 'completed', 0, '2026-10-28 18:35:56.473754+00', '2026-10-28 18:35:58.363+00', '2026-10-28 18:35:58.363+00', true);
INSERT INTO public.calls VALUES ('723a4bd9-8a1a-4510-bf62-a6add276f6eb', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', NULL, 'audio', 'completed', 0, '2026-10-28 18:42:26.096006+00', '2026-10-28 18:42:33.108+00', '2026-10-28 18:42:33.108+00', true);
INSERT INTO public.calls VALUES ('c3111ee1-f57e-488e-b0ea-6fd5a30c74ac', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', NULL, 'audio', 'ongoing', 0, '2026-10-28 18:42:28.775374+00', NULL, NULL, true);
INSERT INTO public.calls VALUES ('473f7d3d-c2df-4d9b-b04c-e0032f17976c', '80e2ce45-6d30-4b3e-8a39-605874b04592', 'b1ce2ad3-9138-4827-ba3d-3a94b03be47f', NULL, 'audio', 'ongoing', 0, '2026-10-29 00:03:14.283165+00', NULL, NULL, false);


--
-- Data for Name: conversation_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.conversation_members VALUES ('7a625b76-551d-4a6a-a540-a468874fd95d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '2026-10-27 19:34:10.816674+00', 'member', false, false, false, 0, 5, '', false);
INSERT INTO public.conversation_members VALUES ('7a625b76-551d-4a6a-a540-a468874fd95d', '5b3b2071-0663-4034-ad70-d63d30b378b8', '2026-10-27 19:34:10.816674+00', 'admin', false, false, false, 0, 7, '', false);
INSERT INTO public.conversation_members VALUES ('2001d24a-1ae4-41a0-9f69-1088fb210a2d', '42f88079-1575-43a3-89fa-fd15eefdeb78', '2026-10-28 18:34:03.980258+00', 'admin', false, false, false, 0, 100, '', false);
INSERT INTO public.conversation_members VALUES ('2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '2026-10-28 18:34:03.980258+00', 'member', false, false, false, 0, 103, '', false);
INSERT INTO public.conversation_members VALUES ('0533d938-5c9c-45c1-aaf4-92e784fd04bb', '65960192-c89e-471f-9ef9-8063e26ec2de', '2026-10-28 20:35:48.943053+00', 'member', false, false, false, 0, 75, '', false);
INSERT INTO public.conversation_members VALUES ('0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '2026-10-28 20:35:48.943053+00', 'admin', false, false, false, 0, 78, '', false);
INSERT INTO public.conversation_members VALUES ('6a54da53-ef5b-4460-aa66-0adeff355c2b', 'b1ce2ad3-9138-4827-ba3d-3a94b03be47f', '2026-10-29 00:04:30.64534+00', 'member', false, false, false, 0, 0, '', false);
INSERT INTO public.conversation_members VALUES ('6a54da53-ef5b-4460-aa66-0adeff355c2b', '80e2ce45-6d30-4b3e-8a39-605874b04592', '2026-10-29 00:04:30.64534+00', 'admin', false, false, false, 0, 0, '', false);


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.conversations VALUES ('61da6880-f275-4b30-a592-f55a790c6ab7', 'direct', '2045556f-ab00-4d65-8a84-1e0012876738:b9abaf00-88b9-4a44-a3ac-e77e69bd6bb2', NULL, 6, '2026-10-27 18:11:00.777+00', '2026-10-27 18:11:00.211007+00', NULL, '', NULL, false);
INSERT INTO public.conversations VALUES ('d1f0d592-945a-429f-b5e2-c1069fee2743', 'direct', '3c5f51da-214d-4a91-a5dc-2e547783e542:6c9645fd-2cae-4600-984a-ef7641db4fba', NULL, 9, '2026-10-27 18:11:18.256+00', '2026-10-27 18:11:17.592691+00', NULL, '', NULL, false);
INSERT INTO public.conversations VALUES ('53e0ffa8-7d16-49a7-bd51-fe246cbe3c7a', 'direct', '349cd3ce-9b6a-4182-a7dd-4e7a6beeeee5:b9f79b8b-cdfb-40af-87f3-3ea949bfc1fb', NULL, 5, '2026-10-27 18:07:59.755+00', '2026-10-27 18:07:59.626032+00', NULL, '', NULL, false);
INSERT INTO public.conversations VALUES ('31b12454-e44d-4b7a-8dc1-19eb1430cb42', 'group', NULL, NULL, 3, '2026-10-27 18:07:59.859+00', '2026-10-27 18:07:59.81493+00', 'مجموعة الأصدقاء', 'مجموعة النقاش الرسمية', NULL, true);
INSERT INTO public.conversations VALUES ('d9427c85-6806-4436-9329-6388697532a8', 'direct', '74f982ec-f657-4fa9-ba56-7c80a8d25b9c:84f41b7f-7756-405f-adf5-e9bef7811858', NULL, 5, '2026-10-27 18:11:24.581+00', '2026-10-27 18:11:24.499531+00', NULL, '', NULL, false);
INSERT INTO public.conversations VALUES ('6ceafc28-872d-4168-8e08-acc12fbd2536', 'group', NULL, NULL, 3, '2026-10-27 18:11:24.653+00', '2026-10-27 18:11:24.622377+00', 'مجموعة الأصدقاء', 'مجموعة النقاش الرسمية', NULL, true);
INSERT INTO public.conversations VALUES ('7a625b76-551d-4a6a-a540-a468874fd95d', 'direct', '5b3b2071-0663-4034-ad70-d63d30b378b8:d8f0bb72-70ed-498a-874a-3c7786d9b71a', '5b3b2071-0663-4034-ad70-d63d30b378b8', 7, '2026-10-27 19:35:46.986+00', '2026-10-27 19:34:10.816674+00', NULL, '', NULL, false);
INSERT INTO public.conversations VALUES ('c2d32c2e-4076-47e8-896e-d161dba72f6f', 'direct', '326d6a1c-02a7-4aaf-9fc8-ffed45409c80:9f65c8c8-18a3-41e4-993a-b019f378b606', NULL, 5, '2026-10-27 20:06:09.002+00', '2026-10-27 20:06:08.908413+00', NULL, '', NULL, false);
INSERT INTO public.conversations VALUES ('b29bd618-ff62-4f4e-abd4-ec6b30a11e0a', 'group', NULL, NULL, 3, '2026-10-27 20:06:09.09+00', '2026-10-27 20:06:09.052057+00', 'مجموعة الأصدقاء', 'مجموعة النقاش الرسمية', NULL, true);
INSERT INTO public.conversations VALUES ('0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'direct', '65960192-c89e-471f-9ef9-8063e26ec2de:d8f0bb72-70ed-498a-874a-3c7786d9b71a', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', 78, '2026-10-28 20:41:03.683+00', '2026-10-28 20:35:48.943053+00', NULL, '', NULL, false);
INSERT INTO public.conversations VALUES ('6a54da53-ef5b-4460-aa66-0adeff355c2b', 'direct', '80e2ce45-6d30-4b3e-8a39-605874b04592:b1ce2ad3-9138-4827-ba3d-3a94b03be47f', '80e2ce45-6d30-4b3e-8a39-605874b04592', 0, NULL, '2026-10-29 00:04:30.64534+00', NULL, '', NULL, false);
INSERT INTO public.conversations VALUES ('2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'direct', '42f88079-1575-43a3-89fa-fd15eefdeb78:d8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', 103, '2026-10-28 18:51:22.456+00', '2026-10-28 18:34:03.980258+00', NULL, '', NULL, false);


--
-- Data for Name: friendships; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.friendships VALUES ('b9286223-e455-49fb-be8d-fcf9e7875222', '5b3b2071-0663-4034-ad70-d63d30b378b8:d8f0bb72-70ed-498a-874a-3c7786d9b71a', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '5b3b2071-0663-4034-ad70-d63d30b378b8', 'accepted', '2026-10-27 19:33:25.770784+00', '2026-10-27 19:34:05.539+00');
INSERT INTO public.friendships VALUES ('65fbb64d-e213-4f61-bfe0-75dfa12b4bc7', '42f88079-1575-43a3-89fa-fd15eefdeb78:d8f0bb72-70ed-498a-874a-3c7786d9b71a', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'accepted', '2026-10-28 18:34:00.611637+00', '2026-10-28 18:34:00.737+00');
INSERT INTO public.friendships VALUES ('3fe9ac02-b089-4a13-86aa-0185f9e6cac7', '65960192-c89e-471f-9ef9-8063e26ec2de:d8f0bb72-70ed-498a-874a-3c7786d9b71a', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '65960192-c89e-471f-9ef9-8063e26ec2de', 'accepted', '2026-10-28 20:35:46.900068+00', '2026-10-28 20:35:56.561+00');


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.messages VALUES ('c5c5fcbb-5603-4a98-bea3-1bf028ff74bb', '7a625b76-551d-4a6a-a540-a468874fd95d', '5b3b2071-0663-4034-ad70-d63d30b378b8', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', 'd29e3d97-34b6-48ac-b001-7942dae62d55', 1, 3, 'text', 'هلا', NULL, 'read', '2026-10-27 19:34:31.261273+00', '2026-10-27 19:34:31.56+00', '2026-10-27 19:34:31.852+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('64374789-d34e-4267-a6a1-a1f560b1160c', '7a625b76-551d-4a6a-a540-a468874fd95d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '5b3b2071-0663-4034-ad70-d63d30b378b8', '95d9653c-8a3b-436e-8ac3-ba5f2f5cd450', 4, 7, 'video', NULL, '48329a84-87a7-483b-8630-54eb6d1b0795', 'read', '2026-10-27 19:35:46.71177+00', '2026-10-27 19:35:47.204+00', '2026-10-27 19:35:47.616+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('d609f461-6f69-4c56-98a9-afd7ca216378', '7a625b76-551d-4a6a-a540-a468874fd95d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '5b3b2071-0663-4034-ad70-d63d30b378b8', 'f780c7d2-3198-431c-bd54-57b386511ddd', 5, 7, 'text', 'هلا', NULL, 'read', '2026-10-27 19:35:46.986207+00', '2026-10-27 19:35:47.204+00', '2026-10-27 19:35:47.616+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('8d4c4e70-db1e-4880-96c2-b793caacc237', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', 'a90aa71a-ed50-4fd9-b04b-42913798b7f2', 85, 88, 'text', 'قوه', NULL, 'read', '2026-10-28 18:39:03.434917+00', '2026-10-28 18:39:06.804+00', '2026-10-28 18:39:07.549+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('2b40eb6b-7d6f-43eb-bd1c-1966c2ee998b', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', '9027ee1f-ef60-4e82-85f3-4a0c96fd2acc', 87, 92, 'audio', NULL, '1c573f4f-ba36-4f7b-b598-19bb45e7e582', 'read', '2026-10-28 18:39:06.806597+00', '2026-10-28 18:39:25.514+00', '2026-10-28 18:39:55.735+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('ead7161f-f1c5-446f-97b4-497cc6b738aa', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', '1dd29b5d-6888-4959-aeae-22e9b7d0956b', 90, 92, 'audio', NULL, '0d87ffde-a292-4f3a-a3d1-05c96d86e7a4', 'read', '2026-10-28 18:39:39.22844+00', '2026-10-28 18:39:39.935+00', '2026-10-28 18:39:55.735+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('27192679-aa32-42c6-94c7-8560882a816a', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', 'd63ed507-e961-47bd-bc81-e165f4f38491', 1, 3, 'text', 'الووو', NULL, 'read', '2026-10-28 18:34:19.038171+00', '2026-10-28 18:34:19.295+00', '2026-10-28 18:34:20.404+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('b92350d9-ee39-4098-ab36-92067477655b', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'dd03f55f-6aa7-4693-8c7e-6002f6fa268b', 4, 6, 'text', 'هلا', NULL, 'read', '2026-10-28 18:34:23.560211+00', '2026-10-28 18:34:24.059+00', '2026-10-28 18:34:24.988+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('b39baa2a-ba61-48c4-ac7e-589d61cfa2e4', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'ea486133-3fb1-4635-99b2-b29d5873947f', 94, 99, 'audio', NULL, 'c01cdc6a-9b55-4003-bd43-9814adbd90a0', 'read', '2026-10-28 18:42:35.888159+00', '2026-10-28 18:48:37.313+00', '2026-10-28 18:48:41.692+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('4441f1c3-7b18-4940-af3d-419c99ea864a', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', 'f66f9e53-c06b-4fa8-9168-9f89d4eb7149', 8, 11, 'text', 'ارحب', NULL, 'read', '2026-10-28 18:34:29.240843+00', '2026-10-28 18:34:29.579+00', '2026-10-28 18:34:30.197+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('0d6cba47-2ea0-4677-9e77-d6bbf672dee5', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', '5c424e87-4546-400c-b538-48e274c2b895', 7, 12, 'text', 'كيفك', NULL, 'read', '2026-10-28 18:34:27.872508+00', '2026-10-28 18:34:29.832+00', '2026-10-28 18:34:30.733+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('b7f0c24b-1ae2-43cf-8ea8-99168abb2280', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '0b40d9c2-a1f0-413f-a20e-a60b6a8561fc', 13, 17, 'text', 'الحمدلله', NULL, 'read', '2026-10-28 18:34:34.364454+00', '2026-10-28 18:34:35.115+00', '2026-10-28 18:34:35.697+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('1a965470-3371-4441-bd62-e18f39a4ef3a', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', '6f401c17-094a-49de-8930-8ac141e7af29', 15, 18, 'text', 'معك خالك', NULL, 'read', '2026-10-28 18:34:35.244391+00', '2026-10-28 18:34:35.532+00', '2026-10-28 18:34:37.413+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('ea695078-ca25-4ef8-8d95-c4a77414417a', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', '50c3db09-6ca3-4cb7-9355-6c28488ca11e', 19, 21, 'text', 'هههههه', NULL, 'read', '2026-10-28 18:34:38.647396+00', '2026-10-28 18:34:39.099+00', '2026-10-28 18:34:40.118+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('cb1531b0-ef6f-4c45-884e-18e1abfc1995', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', 'e1ef65b1-bd5b-4316-897c-7b7fa07f3985', 22, 24, 'text', 'داري', NULL, 'read', '2026-10-28 18:34:41.823695+00', '2026-10-28 18:34:42.115+00', '2026-10-28 18:34:42.406+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('bf9df70a-c86b-4d98-bcd9-b0348511511f', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '49e2c575-3e24-4c54-a52c-f0eb0d26c9a2', 25, 27, 'text', 'ههه', NULL, 'read', '2026-10-28 18:34:46.924372+00', '2026-10-28 18:34:47.56+00', '2026-10-28 18:34:48.052+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('ae49aeca-85a2-4091-8d02-ddd312733ec3', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', '516bc71a-5f04-4e19-932a-1acac29124db', 28, 30, 'text', 'هذه وتس اب صنعته انا', NULL, 'read', '2026-10-28 18:34:49.756336+00', '2026-10-28 18:34:49.817+00', '2026-10-28 18:34:50.216+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('195ab8db-4c44-4027-b671-51e1e817ec0c', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '2c8571aa-da96-4eab-a0b9-05cc24ca9db9', 31, 33, 'text', 'قوه', NULL, 'read', '2026-10-28 18:34:56.947241+00', '2026-10-28 18:34:57.753+00', '2026-10-28 18:34:58.835+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('90f0069c-7fdf-4fd6-8be3-44c62b528486', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', '80a60af6-5897-4ca2-b9d4-8ac33b7a7706', 34, 36, 'text', 'ادخل شوف الحاله حقي', NULL, 'read', '2026-10-28 18:34:58.931185+00', '2026-10-28 18:34:59.193+00', '2026-10-28 18:34:59.605+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('8a832e6d-6d90-4fcc-9f5d-e0faefd5429b', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', '1ba8f477-308e-4140-b750-61e900dfc96a', 37, 39, 'text', 'وفيه حالة', NULL, 'read', '2026-10-28 18:35:15.623204+00', '2026-10-28 18:35:18.058+00', '2026-10-28 18:35:18.541+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('fb8a69b3-fc9f-4647-b5ae-0c8451b3aee5', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', '41ac8d4c-2b60-4dc5-a9fc-416177f62e30', 40, 42, 'text', 'عاد', NULL, 'read', '2026-10-28 18:35:41.679307+00', '2026-10-28 18:35:42.021+00', '2026-10-28 18:35:42.418+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('a2451609-310f-4fac-afe3-8e8d8262adee', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', '911f1676-5544-47bd-8fbf-e21a60bfac2c', 43, 45, 'text', 'الاتصال مقش شغال', NULL, 'read', '2026-10-28 18:35:54.967774+00', '2026-10-28 18:35:55.801+00', '2026-10-28 18:35:56.177+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('53bc2850-de1f-46dc-b431-0b8bcaf6ffaa', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'c1a2c3d0-ddf9-4c11-95cd-1d236a20864a', 46, 48, 'text', 'مقا اضفت الميزه', NULL, 'read', '2026-10-28 18:36:03.311778+00', '2026-10-28 18:36:03.739+00', '2026-10-28 18:36:04.173+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('be277772-942f-477c-866d-e815befd1310', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '72457177-1990-4530-a786-c0f47393c492', 49, 51, 'text', 'ليش', NULL, 'read', '2026-10-28 18:36:04.554127+00', '2026-10-28 18:36:04.689+00', '2026-10-28 18:36:05.468+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('71d9cb17-169d-4652-b545-1b001e308ed5', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '40b31e0e-9906-4425-b429-2aa3c69c2baa', 52, 54, 'text', 'قوه', NULL, 'read', '2026-10-28 18:36:12.100281+00', '2026-10-28 18:36:12.682+00', '2026-10-28 18:36:13.352+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('92e9940f-7f03-4e77-b849-9e2e19b33623', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'a8fdb1cf-8aa0-4fb7-a1d7-23725f004fce', 55, 57, 'text', 'عادنا اطوره', NULL, 'read', '2026-10-28 18:36:22.051362+00', '2026-10-28 18:36:22.633+00', '2026-10-28 18:36:24.039+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('05395de8-9b21-44e5-b359-db779647617e', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', 'aaeacd3b-2d4f-4de0-98fb-fa0db2553165', 58, 60, 'text', 'والله قوه', NULL, 'read', '2026-10-28 18:36:30.944414+00', '2026-10-28 18:36:31.632+00', '2026-10-28 18:36:32.223+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('320040d1-30f3-48d4-bc5f-dab830cf208c', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', '88c8c39a-f017-4290-9505-f4a3dccecfd0', 61, 63, 'audio', NULL, '1cca4230-9e2e-46aa-a0e3-c05d4a4fa52a', 'read', '2026-10-28 18:36:39.781463+00', '2026-10-28 18:36:40.519+00', '2026-10-28 18:36:41.018+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('b59b230c-edd8-4976-a174-dd5443eeb57a', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'fd0cab4d-940e-4a8c-825d-7e39320cdff1', 64, 66, 'audio', NULL, '8cb8302c-2440-4fd6-9962-f080d8baa8c8', 'read', '2026-10-28 18:37:02.318069+00', '2026-10-28 18:37:03.066+00', '2026-10-28 18:37:03.449+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('93e548c6-fbe1-4f5f-a904-7b3815af77f8', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '64665ddc-08f8-42f2-b162-41f5b397374d', 67, 69, 'audio', NULL, 'b28ef1fe-861b-4aeb-afb1-3616bd8d77db', 'read', '2026-10-28 18:37:06.001922+00', '2026-10-28 18:37:07.105+00', '2026-10-28 18:37:07.702+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('87262366-7a5b-4b7b-a174-f9b3cc7def50', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', '71311591-c2b6-43c3-98e7-b2547aa1e17a', 70, 72, 'image', NULL, 'd96496e1-6c49-40cd-8e09-1d70781cc4bc', 'read', '2026-10-28 18:37:19.210535+00', '2026-10-28 18:37:20.361+00', '2026-10-28 18:37:20.806+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('912dc7a1-8148-430e-9af6-20951f9601ec', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '6cd6ebea-e5ce-458e-bf87-3c63a746b53c', 73, 75, 'text', 'رضي', NULL, 'read', '2026-10-28 18:37:23.812061+00', '2026-10-28 18:37:24.914+00', '2026-10-28 18:37:25.61+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('9c8f0a68-54e3-4bec-aa00-30e6a0a10767', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', '26c65b01-7f21-468c-9b4b-fb1114d1a321', 76, 78, 'text', 'قوه', NULL, 'read', '2026-10-28 18:37:29.435135+00', '2026-10-28 18:37:29.961+00', '2026-10-28 18:37:31.22+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('6b6a7ec6-b2db-4221-b924-b9b5dc52776a', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', '29616c31-c3e0-469e-bbe3-24d9fa7cbebe', 79, 81, 'audio', NULL, '8cf56679-2fdb-40c7-a12c-d7df290c485f', 'read', '2026-10-28 18:37:49.80647+00', '2026-10-28 18:37:50.181+00', '2026-10-28 18:37:50.898+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('45d65081-9fac-4a2c-9c96-fcd656ddbdba', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', '8dedab90-14ee-4bdc-87af-af735a0f7e0d', 82, 84, 'audio', NULL, '603eaedd-5cc6-48b6-b40c-f7f5f7dc1c99', 'read', '2026-10-28 18:38:06.183375+00', '2026-10-28 18:38:06.686+00', '2026-10-28 18:38:07.137+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('d46ba955-516a-4929-b8fa-e62b230be309', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '74d74999-f63b-4f3f-8308-121412c13437', 93, 96, 'text', 'ايش اسمه', NULL, 'read', '2026-10-28 18:41:05.8399+00', '2026-10-28 18:42:36.2+00', '2026-10-28 18:42:37.416+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('dc249b6c-9c3f-480c-9e6a-d3cd6beabfa1', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '65960192-c89e-471f-9ef9-8063e26ec2de', 'dd49a98f-5d6a-4acc-a947-6f4ecad385c6', 67, 69, 'text', 'وخله الايفون', NULL, 'read', '2026-10-28 20:39:57.901851+00', '2026-10-28 20:39:58.844+00', '2026-10-28 20:39:59.54+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('315e68da-72fb-4a25-955d-5f768d09517a', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', '5a62630b-6ca7-4bc3-a594-2524311148ac', 97, 99, 'audio', NULL, 'f011d6fa-f18c-4c31-8771-4762c657ad94', 'read', '2026-10-28 18:43:04.285262+00', '2026-10-28 18:48:37.313+00', '2026-10-28 18:48:41.692+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('778c49af-b767-4518-bdbc-d98f050c6ba0', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '65960192-c89e-471f-9ef9-8063e26ec2de', '4ee74ddc-4277-488b-8fd8-367c775934db', 70, 72, 'text', 'شوف فيه الموقع حتا حاله شوف الحاله حقي', NULL, 'read', '2026-10-28 20:40:17.042608+00', '2026-10-28 20:40:17.479+00', '2026-10-28 20:40:17.777+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('a3f0cec2-eba4-4839-87fa-99cf33f22a7e', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', '42f88079-1575-43a3-89fa-fd15eefdeb78', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', 'b642ad46-cda5-442e-8666-28c5506ddf9a', 100, 102, 'text', 'الوو', NULL, 'read', '2026-10-28 18:49:25.863176+00', '2026-10-28 18:51:17.858+00', '2026-10-28 18:51:19.917+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('cf92003e-d9c5-4d32-a6c6-84b0739b3e7b', '2001d24a-1ae4-41a0-9f69-1088fb210a2d', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '42f88079-1575-43a3-89fa-fd15eefdeb78', '8292c25f-4bfd-4da1-b6d2-928dff0afdf8', 103, 103, 'text', 'هلا', NULL, 'sent', '2026-10-28 18:51:22.456872+00', NULL, NULL, NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('6b546b02-7a15-432f-b7a7-7d2bf4c4f5f5', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '65960192-c89e-471f-9ef9-8063e26ec2de', '92a9a0d7-71bc-4805-8d71-f046a7d83a58', 1, 5, 'text', 'هلا', NULL, 'read', '2026-10-28 20:35:52.477601+00', '2026-10-28 20:35:53.766+00', '2026-10-28 20:36:01.418+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('25d7f11c-1ade-41e7-bc46-6509aa8a3916', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '65960192-c89e-471f-9ef9-8063e26ec2de', '3c709178-769c-475f-9dd5-06400004c8b5', 3, 5, 'text', 'واخيرن', NULL, 'read', '2026-10-28 20:35:56.316451+00', '2026-10-28 20:35:56.975+00', '2026-10-28 20:36:01.418+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('45aa16d0-7d26-410f-bb8a-fd0438a8c3bb', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', '65960192-c89e-471f-9ef9-8063e26ec2de', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '55702c1f-284a-47bd-a849-ff2b53397229', 73, 77, 'text', 'ايوه يلله معسلامه قهم ليزنزنو معسلامه', NULL, 'read', '2026-10-28 20:40:25.663074+00', '2026-10-28 20:40:25.942+00', '2026-10-28 20:40:52.426+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('2924e048-72d7-4a00-8f09-81305596fa08', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', '65960192-c89e-471f-9ef9-8063e26ec2de', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '1d426db9-3ef0-4f79-b7ad-33bb09bfac1e', 6, 8, 'text', 'هلا', NULL, 'read', '2026-10-28 20:36:03.962771+00', '2026-10-28 20:36:04.236+00', '2026-10-28 20:36:04.504+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('5763ba90-de34-4072-9ac9-01d09bca380a', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', '65960192-c89e-471f-9ef9-8063e26ec2de', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', 'cce032a5-b778-46e2-bcb8-122f61a44860', 10, 13, 'text', 'ههههه ايوه ولله قوه', NULL, 'read', '2026-10-28 20:36:16.218254+00', '2026-10-28 20:36:16.473+00', '2026-10-28 20:36:16.74+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('a933953a-91cd-41cf-8634-e3bcf24794ae', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '65960192-c89e-471f-9ef9-8063e26ec2de', 'b3098ddf-ab62-485a-b3e8-83b3a530ad1c', 9, 14, 'audio', NULL, '042f6845-e150-492a-b933-d91b56f68265', 'read', '2026-10-28 20:36:10.391317+00', '2026-10-28 20:36:16.319+00', '2026-10-28 20:36:17.912+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('1a5bd32b-1720-4b92-8731-2ade1e59e40c', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '65960192-c89e-471f-9ef9-8063e26ec2de', '40bf206a-8b1a-4df6-b8b7-7b422aafb2d3', 15, 19, 'audio', NULL, '031a6c25-ece3-4ce7-96ef-621610522c3c', 'read', '2026-10-28 20:36:18.973214+00', '2026-10-28 20:36:20.159+00', '2026-10-28 20:36:27.606+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('d586fb6e-0011-4003-bc30-37c4f7ab7cac', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', '65960192-c89e-471f-9ef9-8063e26ec2de', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', 'a2eedc8e-0cf6-4627-b2da-4ddf3e5e354e', 17, 20, 'text', 'اقدر اكلم محمد عبده منه', NULL, 'read', '2026-10-28 20:36:27.072653+00', '2026-10-28 20:36:27.334+00', '2026-10-28 20:36:27.616+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('ff655916-d9b0-42f1-a874-498b483d6ad2', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '65960192-c89e-471f-9ef9-8063e26ec2de', 'f3ab7740-5212-41fc-95b9-153f37d646ca', 21, 23, 'text', 'محمد رسلني على طول', NULL, 'read', '2026-10-28 20:36:33.102305+00', '2026-10-28 20:36:34.14+00', '2026-10-28 20:36:34.713+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('8e31ec31-a222-40ab-8d84-b07a1f5539c6', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '65960192-c89e-471f-9ef9-8063e26ec2de', '9de503e3-1cd1-46ef-a7f6-0984fe1094a0', 24, 26, 'image', NULL, '65ba11d6-8686-4b94-a212-6629431af417', 'read', '2026-10-28 20:36:46.460189+00', '2026-10-28 20:36:47.32+00', '2026-10-28 20:36:47.897+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('7ed43d3a-e583-41a0-9866-5415eb29e9c2', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '65960192-c89e-471f-9ef9-8063e26ec2de', '739b3f55-07a7-47cd-8b9f-aaa099c5a767', 27, 29, 'text', 'شوف', NULL, 'read', '2026-10-28 20:36:50.235043+00', '2026-10-28 20:36:50.647+00', '2026-10-28 20:36:51.169+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('fbe03326-cd88-417c-995c-bbd1d01e661b', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', '65960192-c89e-471f-9ef9-8063e26ec2de', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', 'ef0107a2-d1fa-45c9-a7b3-8f665239a1f6', 30, 32, 'audio', NULL, 'cc0bd85d-5260-43ca-9d97-c9f5e26896e7', 'read', '2026-10-28 20:36:59.909922+00', '2026-10-28 20:37:00.233+00', '2026-10-28 20:37:00.515+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('a6cd120c-b8c8-41ba-8310-ddf5308b79ac', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', '65960192-c89e-471f-9ef9-8063e26ec2de', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '68e993d9-2159-48a6-a58b-7d68168f4c80', 33, 35, 'text', 'ولله قوه', NULL, 'read', '2026-10-28 20:37:21.027416+00', '2026-10-28 20:37:21.299+00', '2026-10-28 20:37:21.592+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('a58550a1-f2b5-4302-b486-044a538205cb', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', '65960192-c89e-471f-9ef9-8063e26ec2de', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '877a36e4-f069-4420-a33a-2c7c1882ddeb', 36, 38, 'text', 'خلص ايبزو انترنت', NULL, 'read', '2026-10-28 20:37:37.772843+00', '2026-10-28 20:37:38.035+00', '2026-10-28 20:37:38.3+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('47d67c3d-af1b-41cd-b70d-c38c6c576960', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', '65960192-c89e-471f-9ef9-8063e26ec2de', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '095c2c9c-15a9-40f2-a90f-f55b69b72157', 39, 42, 'text', 'شبيه ذا الجوال ٣٥٠ ريال وشتري جلكسي', NULL, 'read', '2026-10-28 20:37:58.733083+00', '2026-10-28 20:38:08.356+00', '2026-10-28 20:38:09.217+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('e70ec657-4c63-4100-b06c-48baa8710ffb', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', '65960192-c89e-471f-9ef9-8063e26ec2de', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '92e86cf6-22fb-48f1-8896-47548194370b', 40, 42, 'text', 'واو', NULL, 'read', '2026-10-28 20:38:07.933117+00', '2026-10-28 20:38:08.356+00', '2026-10-28 20:38:09.217+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('81bb8d72-b3f0-4fff-911e-b912fe4e9d9d', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', '65960192-c89e-471f-9ef9-8063e26ec2de', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '7cdfc2c7-439c-4a3b-9ca7-2f66cfedb2c1', 43, 45, 'text', 'لان ماشي به شريحه أبيعه أو لا جديد بلكرتون والبطاريه ٩٨', NULL, 'read', '2026-10-28 20:38:49.351149+00', '2026-10-28 20:38:50.546+00', '2026-10-28 20:38:51.377+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('5e0e499b-ed9d-4738-bcb8-97f22e155ef1', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '65960192-c89e-471f-9ef9-8063e26ec2de', 'e15916e5-482f-4380-a754-6b4931e272e9', 46, 51, 'video', NULL, 'ee64f00a-326d-4b1f-bcc4-3ca87c564121', 'read', '2026-10-28 20:38:53.101019+00', '2026-10-28 20:38:55.495+00', '2026-10-28 20:38:56.63+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('f92cf5de-52fb-4ac7-9711-0d882aa07604', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '65960192-c89e-471f-9ef9-8063e26ec2de', '80315214-75fb-4d44-ab70-021a9e05876c', 47, 51, 'audio', NULL, 'c11c4353-68d4-452f-b9da-ef157e2685ef', 'read', '2026-10-28 20:38:54.553628+00', '2026-10-28 20:38:55.495+00', '2026-10-28 20:38:56.63+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('4434383c-e8c9-4d33-9088-4557b4bd044e', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '65960192-c89e-471f-9ef9-8063e26ec2de', '1c552b91-5090-4b23-9c00-60d40817d1ba', 48, 51, 'text', 'كون راسلني منه', NULL, 'read', '2026-10-28 20:38:54.826734+00', '2026-10-28 20:38:55.495+00', '2026-10-28 20:38:56.63+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('d99c08ea-5979-4455-9194-dcf991eb4e69', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '65960192-c89e-471f-9ef9-8063e26ec2de', '79038b96-48b3-4213-a227-c8a9cd05a756', 49, 51, 'text', 'برسلك فيديو كيف تخليه برنامج', NULL, 'read', '2026-10-28 20:38:55.088982+00', '2026-10-28 20:38:55.495+00', '2026-10-28 20:38:56.63+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('719510c0-be0d-424d-bef3-df591726ff42', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', '65960192-c89e-471f-9ef9-8063e26ec2de', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '848e3f50-ad8c-4c43-8214-a3e83ee1edb3', 52, 54, 'text', 'ايوه بس بكره', NULL, 'read', '2026-10-28 20:39:13.684157+00', '2026-10-28 20:39:14.001+00', '2026-10-28 20:39:14.272+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('002ab72d-e479-4098-b3b8-e48f078e2cf0', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '65960192-c89e-471f-9ef9-8063e26ec2de', 'e043e88f-9d5e-48a6-be06-dfa4ad6f6070', 55, 57, 'text', 'شل لك واحد جوال رخيص عشان الشريحه', NULL, 'read', '2026-10-28 20:39:19.161982+00', '2026-10-28 20:39:20.406+00', '2026-10-28 20:39:22.982+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('a4a23c3a-a52a-4b6e-bed2-0b0a290db9b4', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', '65960192-c89e-471f-9ef9-8063e26ec2de', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', 'aecf8b00-5453-447a-aaa8-5bbdaff95348', 59, 61, 'text', 'إيش رأيك', NULL, 'read', '2026-10-28 20:39:28.327653+00', '2026-10-28 20:39:28.491+00', '2026-10-28 20:39:28.909+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('d4536120-a69c-4e85-88ce-97aba2294372', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '65960192-c89e-471f-9ef9-8063e26ec2de', 'b0fe1d66-7214-42de-8d30-af145563bbd5', 58, 63, 'text', 'بميه ميتين', NULL, 'read', '2026-10-28 20:39:27.926532+00', '2026-10-28 20:39:31.043+00', '2026-10-28 20:39:34.049+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('366acb4e-6212-43d6-81dd-51b716bcfaea', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '65960192-c89e-471f-9ef9-8063e26ec2de', '123a9b46-9e79-4234-b2e0-8d15d02de07f', 64, 66, 'text', 'شللك جوال رخيص لشريحه', NULL, 'read', '2026-10-28 20:39:52.610775+00', '2026-10-28 20:39:53.108+00', '2026-10-28 20:39:53.785+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('d430b0a0-0093-43e5-8052-f5be6ab7691b', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', '65960192-c89e-471f-9ef9-8063e26ec2de', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', 'c26aeb2a-86a8-427e-a2dd-3426ec31b32b', 75, 77, 'text', 'ولله بهذله ليهونونا هيانه بكره اشتري شريحه', NULL, 'read', '2026-10-28 20:40:43.907226+00', '2026-10-28 20:40:44.224+00', '2026-10-28 20:40:52.426+00', NULL, NULL, NULL, false);
INSERT INTO public.messages VALUES ('6a978172-5f04-4a36-8c53-233275521061', '0533d938-5c9c-45c1-aaf4-92e784fd04bb', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '65960192-c89e-471f-9ef9-8063e26ec2de', '9ddfee56-12f1-4c80-a69a-b1606c02e892', 78, 78, 'text', 'يالله', NULL, 'sent', '2026-10-28 20:41:03.682899+00', NULL, NULL, NULL, NULL, NULL, false);


--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.sessions VALUES ('25398dc6-793e-4924-9444-3bc5bf0502a6', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '9240b1156ccf1af3d91c1e5e8f7b6e1a59281d9c8695c95ecf11f499d7c2fb38', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.7 Mobile/15E148 Safari/604.1', '10.12.0.76', '2026-10-27 14:20:48.5522+00', '2026-10-27 16:54:39.805+00', '2026-11-26 16:54:39.805+00');
INSERT INTO public.sessions VALUES ('cf39bf30-097a-4bdb-bba1-386b02e99f54', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', 'e7194fd04d25495bd786627fa7fbe841642236f5150c34e162009dc8d5340de0', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.7 Mobile/15E148 Safari/604.1', '10.12.0.112', '2026-10-27 18:27:12.197803+00', '2026-10-27 19:35:33.276+00', '2026-11-26 19:35:33.276+00');
INSERT INTO public.sessions VALUES ('1dc2870b-124f-4cf8-8a3d-c99d31040810', '5b3b2071-0663-4034-ad70-d63d30b378b8', '4b062d3c564efb1fba64b172924a08cfc2740998cd924612e69ddf3d78d782f4', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '10.12.0.14', '2026-10-27 19:32:42.725232+00', '2026-10-27 19:56:23.398+00', '2026-11-26 19:56:23.398+00');
INSERT INTO public.sessions VALUES ('c57f8fe3-0651-498d-8a12-59e83d29da70', '42f88079-1575-43a3-89fa-fd15eefdeb78', '602d05eb81e4cb3040edd1ba0c4fb89fac712670e57760434e63dfdc495dbd23', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Mobile Safari/537.36', '10.12.0.104', '2026-10-28 18:31:39.767452+00', '2026-10-28 18:41:44.812+00', '2026-11-27 18:41:44.812+00');
INSERT INTO public.sessions VALUES ('85834d57-0463-4dd8-b483-dbba641ff732', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '7bb19dfbd36941ec157e3ecccb25c0de3c996c92760edec952e325289c77cf92', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.7 Mobile/15E148 Safari/604.1', '10.12.0.116', '2026-10-28 18:43:52.861644+00', '2026-10-28 19:07:34.091+00', '2026-11-27 19:07:34.091+00');
INSERT INTO public.sessions VALUES ('89724e07-48d8-431b-ba6d-a99942bf8966', '65960192-c89e-471f-9ef9-8063e26ec2de', '90467d83a5acfce21d70a44985eda98f7190244c113371e63293098c5ded5ffb', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/27.0.1 Mobile/15E148 Safari/604.1', '10.12.0.2', '2026-10-28 20:26:00.118849+00', '2026-10-28 20:36:00.252+00', '2026-11-27 20:36:00.252+00');
INSERT INTO public.sessions VALUES ('b0d34bd2-2c65-465f-83c7-edfbfa87a92e', '80e2ce45-6d30-4b3e-8a39-605874b04592', '5c444b1443fc3aefbace8adfb6e989454354150a00c7f24fdda44e08a4289223', 'curl/7.88.1', '10.12.0.132', '2026-10-29 00:02:50.912652+00', '2026-10-29 00:02:50.912652+00', '2026-11-28 00:02:50.912+00');
INSERT INTO public.sessions VALUES ('ab8118ff-653e-45c1-af83-a1432911fb52', 'b1ce2ad3-9138-4827-ba3d-3a94b03be47f', 'a7803dfd2a84a2746f41c003d7aa3566124026da8961fb0c31b86b46dea3871f', 'curl/7.88.1', '10.12.0.132', '2026-10-29 00:03:11.375515+00', '2026-10-29 00:03:11.375515+00', '2026-11-28 00:03:11.375+00');
INSERT INTO public.sessions VALUES ('8354b488-07ad-4aa8-8f2b-811a53ea8dc4', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', '99ca4eff29644182d598ea23bb796565f09c9d9b17df435580d3fc1e73bf9f6c', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.7 Mobile/15E148 Safari/604.1', '10.12.0.176', '2026-10-29 00:35:07.920969+00', '2026-10-29 00:35:07.920969+00', '2026-11-28 00:35:07.92+00');


--
-- Data for Name: status_views; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.status_views VALUES ('0f797a0a-e97f-4c58-925d-4cbbf9af22e4', '5b3b2071-0663-4034-ad70-d63d30b378b8', '2026-10-27 19:37:54.525767+00');
INSERT INTO public.status_views VALUES ('6e4aed56-fba9-40b4-ab47-26091855eff9', '42f88079-1575-43a3-89fa-fd15eefdeb78', '2026-10-28 18:39:34.077759+00');


--
-- Data for Name: statuses; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.statuses VALUES ('0f797a0a-e97f-4c58-925d-4cbbf9af22e4', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', 'video', NULL, '3d520ade-d12c-408a-ae53-1ba6008f5e66', '#059669', 'default', 'friends', '2026-10-27 19:36:45.306507+00', '2026-10-28 19:36:42.56+00');
INSERT INTO public.statuses VALUES ('6e4aed56-fba9-40b4-ab47-26091855eff9', 'd8f0bb72-70ed-498a-874a-3c7786d9b71a', 'video', NULL, 'db75b0f8-10fc-4956-be3b-81480eb094a8', '#059669', 'default', 'friends', '2026-10-27 19:43:31.748758+00', '2026-10-28 19:43:24.952+00');


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.users VALUES ('5b3b2071-0663-4034-ad70-d63d30b378b8', 'FID-3LSZ', 'mosa@gmail.com', 'user_3lsz', 'الكمبيوتر', 'مرحبًا! أنا أستخدم Friend ID.', '$2b$11$1eA51UuZLRWky3Emze3aR.o8ShhsaCAX5u17E6f91SSAm961wIDEe', NULL, true, 'everyone', true, '2026-10-27 19:32:45.444+00', '2026-10-27 19:32:42.714591+00', '2026-10-27 19:32:42.714591+00', 'light', '#059669', '', true, true, true, true, 'everyone', 'friends');
INSERT INTO public.users VALUES ('d8f0bb72-70ed-498a-874a-3c7786d9b71a', 'FR-572919', 'abdo.noman2500@gmail.com', 'user572919', 'عبده', '', '$2b$11$6tl8mDPSve2ZJZ8g2a.pBuygYgQykrqG4DcQQXbAzSOwb4ly3noQW', NULL, true, 'everyone', true, '2026-10-29 00:35:49.957+00', '2026-10-27 14:20:48.548638+00', '2026-10-27 19:38:28.751+00', 'light', '#059669', 'dark', true, true, true, true, 'everyone', 'everyone');
INSERT INTO public.users VALUES ('42f88079-1575-43a3-89fa-fd15eefdeb78', 'FID-Z7BR', 'kcpwncib@gmail.com', '2024', 'jhei', 'مرحبًا! أنا أستخدم Friend ID.', '$2b$11$F2imK8AHtcikhC4SAQ4mgOijTr9wGszWUn/2svZjhYjus4h0GX9z.', NULL, true, 'everyone', true, '2026-10-28 18:50:02.369+00', '2026-10-28 18:31:39.765411+00', '2026-10-28 18:31:39.765411+00', 'light', '#059669', '', true, true, true, true, 'everyone', 'friends');
INSERT INTO public.users VALUES ('65960192-c89e-471f-9ef9-8063e26ec2de', 'FID-SDSQ', 'abode1445@icloud.com', 'fnks30', 'عبدالحكيم', 'مرحبًا! أنا أستخدم Friend ID.', '$2b$11$BBqOh95BHgaXJf1Nr9VE8OkPFSFeV.De3l0x.IflnGArzEmHoMcSW', NULL, true, 'everyone', true, '2026-10-28 20:43:57.489+00', '2026-10-28 20:26:00.11707+00', '2026-10-28 20:26:00.11707+00', 'light', '#059669', '', true, true, true, true, 'everyone', 'friends');
INSERT INTO public.users VALUES ('b1ce2ad3-9138-4827-ba3d-3a94b03be47f', 'FID-8V7L', 'probe_test_992@friendid.test', 'probe992', 'Peer B', 'مرحبًا! أنا أستخدم Friend ID.', '$2b$11$GN.bQHnKdVvnWAH8dimvIOwq4u82e7ln7aiY.0jeDE9IP6YLa1FI.', NULL, true, 'everyone', true, '2026-10-29 00:04:20.931+00', '2026-10-29 00:03:11.373724+00', '2026-10-29 00:03:11.373724+00', 'light', '#059669', '', true, true, true, true, 'everyone', 'friends');
INSERT INTO public.users VALUES ('80e2ce45-6d30-4b3e-8a39-605874b04592', 'FID-5KAF', 'probe_test_991@friendid.test', 'probe991', 'Probe User', 'مرحبًا! أنا أستخدم Friend ID.', '$2b$11$PTNSB8y3W5bf0yPZfxyPZe7ivI1ikDs7RNXVVOUT.CX.QI908mrYq', NULL, true, 'everyone', true, '2026-10-29 00:04:36.203+00', '2026-10-29 00:02:50.909381+00', '2026-10-29 00:02:50.909381+00', 'light', '#059669', '', true, true, true, true, 'everyone', 'friends');


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: blocks blocks_blocker_id_blocked_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blocks
    ADD CONSTRAINT blocks_blocker_id_blocked_id_pk PRIMARY KEY (blocker_id, blocked_id);


--
-- Name: calls calls_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calls
    ADD CONSTRAINT calls_pkey PRIMARY KEY (id);


--
-- Name: conversation_members conversation_members_conversation_id_user_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversation_members
    ADD CONSTRAINT conversation_members_conversation_id_user_id_pk PRIMARY KEY (conversation_id, user_id);


--
-- Name: conversations conversations_direct_key_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_direct_key_unique UNIQUE (direct_key);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: friendships friendships_pair_key_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.friendships
    ADD CONSTRAINT friendships_pair_key_unique UNIQUE (pair_key);


--
-- Name: friendships friendships_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.friendships
    ADD CONSTRAINT friendships_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_token_hash_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_token_hash_unique UNIQUE (token_hash);


--
-- Name: status_views status_views_status_id_viewer_id_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_views
    ADD CONSTRAINT status_views_status_id_viewer_id_pk PRIMARY KEY (status_id, viewer_id);


--
-- Name: statuses statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.statuses
    ADD CONSTRAINT statuses_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_public_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_public_id_unique UNIQUE (public_id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: attachments_conversation_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX attachments_conversation_idx ON public.attachments USING btree (conversation_id);


--
-- Name: calls_caller_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX calls_caller_idx ON public.calls USING btree (caller_id);


--
-- Name: calls_receiver_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX calls_receiver_idx ON public.calls USING btree (receiver_id);


--
-- Name: calls_started_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX calls_started_idx ON public.calls USING btree (started_at);


--
-- Name: friendships_addressee_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX friendships_addressee_idx ON public.friendships USING btree (addressee_id);


--
-- Name: friendships_requester_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX friendships_requester_idx ON public.friendships USING btree (requester_id);


--
-- Name: members_user_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX members_user_idx ON public.conversation_members USING btree (user_id);


--
-- Name: messages_attachment_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX messages_attachment_idx ON public.messages USING btree (attachment_id);


--
-- Name: messages_conversation_change_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX messages_conversation_change_idx ON public.messages USING btree (conversation_id, change_seq);


--
-- Name: messages_conversation_seq_uq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX messages_conversation_seq_uq ON public.messages USING btree (conversation_id, seq);


--
-- Name: messages_recipient_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX messages_recipient_status_idx ON public.messages USING btree (recipient_id, status);


--
-- Name: messages_sender_client_uq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX messages_sender_client_uq ON public.messages USING btree (sender_id, client_id);


--
-- Name: sessions_expires_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sessions_expires_idx ON public.sessions USING btree (expires_at);


--
-- Name: sessions_user_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sessions_user_idx ON public.sessions USING btree (user_id);


--
-- Name: statuses_expires_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX statuses_expires_idx ON public.statuses USING btree (expires_at);


--
-- Name: statuses_user_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX statuses_user_idx ON public.statuses USING btree (user_id);


--
-- Name: attachments attachments_conversation_id_conversations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_conversation_id_conversations_id_fk FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: attachments attachments_owner_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_owner_id_users_id_fk FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: blocks blocks_blocked_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blocks
    ADD CONSTRAINT blocks_blocked_id_users_id_fk FOREIGN KEY (blocked_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: blocks blocks_blocker_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blocks
    ADD CONSTRAINT blocks_blocker_id_users_id_fk FOREIGN KEY (blocker_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: calls calls_caller_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calls
    ADD CONSTRAINT calls_caller_id_users_id_fk FOREIGN KEY (caller_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: calls calls_conversation_id_conversations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calls
    ADD CONSTRAINT calls_conversation_id_conversations_id_fk FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE SET NULL;


--
-- Name: calls calls_receiver_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calls
    ADD CONSTRAINT calls_receiver_id_users_id_fk FOREIGN KEY (receiver_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: conversation_members conversation_members_conversation_id_conversations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversation_members
    ADD CONSTRAINT conversation_members_conversation_id_conversations_id_fk FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: conversation_members conversation_members_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversation_members
    ADD CONSTRAINT conversation_members_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: conversations conversations_created_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_created_by_users_id_fk FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: friendships friendships_addressee_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.friendships
    ADD CONSTRAINT friendships_addressee_id_users_id_fk FOREIGN KEY (addressee_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: friendships friendships_requester_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.friendships
    ADD CONSTRAINT friendships_requester_id_users_id_fk FOREIGN KEY (requester_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: messages messages_attachment_id_attachments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_attachment_id_attachments_id_fk FOREIGN KEY (attachment_id) REFERENCES public.attachments(id) ON DELETE SET NULL;


--
-- Name: messages messages_conversation_id_conversations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_conversations_id_fk FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: messages messages_sender_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_sender_id_users_id_fk FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reports reports_reported_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_reported_id_users_id_fk FOREIGN KEY (reported_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reports reports_reporter_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_reporter_id_users_id_fk FOREIGN KEY (reporter_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: status_views status_views_status_id_statuses_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_views
    ADD CONSTRAINT status_views_status_id_statuses_id_fk FOREIGN KEY (status_id) REFERENCES public.statuses(id) ON DELETE CASCADE;


--
-- Name: status_views status_views_viewer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_views
    ADD CONSTRAINT status_views_viewer_id_users_id_fk FOREIGN KEY (viewer_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: statuses statuses_attachment_id_attachments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.statuses
    ADD CONSTRAINT statuses_attachment_id_attachments_id_fk FOREIGN KEY (attachment_id) REFERENCES public.attachments(id) ON DELETE CASCADE;


--
-- Name: statuses statuses_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.statuses
    ADD CONSTRAINT statuses_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict wei7zNf8XlgkmhVBWS5GzlRNrFQt764XZaYmTbvdZ8F4EcbLTfYvhmN58Ltr8OI

